class IndexModel{
  double? Gold;
  double? Crypto;
  double? Sensex;
  double? SenSgx;

  IndexModel({this.Gold,this.Sensex,this.Crypto,this.SenSgx});
  //data from server

  factory IndexModel.fromMap(map){
    return IndexModel(
        Gold: map['Gold'],
        Crypto: map['Crypto'],
        Sensex: map['Sensex'],
        SenSgx:map['SenSgx']
    );
  }


  Map<String,dynamic> toMap(){
    return{
      "Gold":Gold,
      "Crypto":Crypto,
      "Sensex":Sensex,
      "SenSgx":SenSgx

    };
  }

}