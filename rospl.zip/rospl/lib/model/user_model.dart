class UserModel{
  String? uid;
  String? email;
  String? username;
  String? choice;

  UserModel({this.uid,this.email,this.username,this.choice});
  //data from server

  factory UserModel.fromMap(map){
    return UserModel(
      uid: map['uid'],
      email: map['email'],
      username: map['username'],
      choice: map['choice'],
    );
  }


  Map<String,dynamic> toMap(){
    return{
      'uid':uid,
      'email':email,
      'username':username,
      'choice':choice,
    };
  }

}