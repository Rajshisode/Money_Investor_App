import 'package:rospl/model/user_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:rospl/screens/index.dart';
import 'home_screen.dart';
import 'package:fluttertoast/fluttertoast.dart';


class SignupScreen extends StatefulWidget {
  const SignupScreen({Key? key}) : super(key: key);
  @override
  _SignupScreenState createState() => _SignupScreenState();
}
class _SignupScreenState extends State<SignupScreen>{

  final _auth=FirebaseAuth.instance;
  //form key
  final _formkey = GlobalKey<FormState>();

  //editing controller
  final TextEditingController emailController = new TextEditingController();
  final TextEditingController passwordController = new TextEditingController();
  final TextEditingController confirmPasswordController = new TextEditingController();
  final TextEditingController usernameController = new TextEditingController();

  String choice="LOW";




  @override
  Widget build(BuildContext context) {


    final emailField = TextFormField(
      autofocus: false,
      controller: emailController,
      keyboardType: TextInputType.emailAddress,
      validator: (value){
        if(value!.isEmpty){
          return ("Please Enter Email");
        }
        if (!RegExp("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+.[a-z]").hasMatch(value)) {
          return ("Please Enter a valid email");
        }
        return null;
      },
      onSaved: (value) {
        emailController.text = value!;
      },
      textInputAction: TextInputAction.next,
      decoration: InputDecoration(
        prefixIcon: Icon(Icons.mail),
        contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
        hintText: "Email",
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );

    final passwordField = TextFormField(
      autofocus: false,
      controller: passwordController,
      obscureText: true,
      validator: (value) {
        RegExp regex = new RegExp(r'^.{8,}$');
        if (value!.isEmpty) {
          return ("Password is required for login");
        }
        if (!regex.hasMatch(value)) {
          return ("Enter Valid Password(Min. 8 Character)");
        }
      },
      onSaved: (value) {
        passwordController.text = value!;
      },
      textInputAction: TextInputAction.next,
      decoration: InputDecoration(
        prefixIcon: Icon(Icons.vpn_key_outlined),
        contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
        hintText: "Password",
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );

    final confirmPasswordField = TextFormField(
      autofocus: false,
      controller: confirmPasswordController,
      obscureText: true,
      validator: (value) {
        if(passwordController.text != confirmPasswordController.text) {
          return "Passwords doesn't match";
        }
      },
      onSaved: (value) {
        confirmPasswordController.text = value!;
      },
      textInputAction: TextInputAction.next,
      decoration: InputDecoration(
        prefixIcon: Icon(Icons.vpn_key),
        contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
        hintText: "Confirm Password",
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );

    final usernameField = TextFormField(
      autofocus: false,
      controller: usernameController,
      validator: (value) {

        RegExp regex = new RegExp(r'^.{8,}$');
        if (value!.isEmpty) {
          return ("Username is required for login");
        }
        if (!regex.hasMatch(value)) {
          return ("Enter Valid Username(Min. 8 Character)");
        }
        return null;
      },
      onSaved: (value) {
        usernameController.text = value!;
      },
      textInputAction: TextInputAction.next,
      decoration: InputDecoration(
        prefixIcon: Icon(Icons.account_box_outlined),
        contentPadding: EdgeInsets.fromLTRB(20, 15, 20, 15),
        hintText: "Username",
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );

    final signupButton = Material(

      elevation: 10,
      borderRadius: BorderRadius.circular(38),
      child: MaterialButton(
        padding: EdgeInsets.fromLTRB(20, 15, 20, 15),
        minWidth: MediaQuery.of(context).size.width,
        onPressed: () {
          signUp(emailController.text, passwordController.text);

        },
        child: Text(
          "SignUp",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_outlined,color: Colors.grey),
          onPressed: (){
            Navigator.of(context).pop();
          },
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
            child: Container(
                child: Padding(
                    padding: const EdgeInsets.all(36.0),
                    child: Form(
                      key: _formkey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          SizedBox(
                            height: 180,
                            child: Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.contain,
                                  image: AssetImage('logo.png'),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 45),
                          usernameField,
                          SizedBox(height: 20),
                          emailField,
                          SizedBox(height: 20),
                          passwordField,
                          SizedBox(height: 20),
                          confirmPasswordField,
                          SizedBox(height: 20),
                          Text("What Level Of Risk you can take?",
                              style: TextStyle(
                                fontSize: 17,
                              )),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [

                              Text('High'),
                              Radio(
                                value: "HIGH",
                                groupValue: choice,
                                activeColor: Colors.red,
                                onChanged: (value) {
                                  setState(() {
                                    this.choice = value.toString();
                                    print(choice);
                                  });
                                },
                              ),
                              Text('Mid'),
                              Radio(
                                value: "MID",
                                groupValue: choice,
                                activeColor: Colors.yellow,
                                onChanged: (value) {
                                  setState(() {
                                    this.choice = value.toString();
                                    print(choice);
                                  });
                                },
                              ),
                              Text('LOW'),
                              Radio(
                                value: "LOW",
                                groupValue: choice,
                                activeColor: Colors.green,
                                onChanged: (value) {
                                  setState(() {
                                    this.choice = value.toString();
                                    print(choice);
                                  });
                                },
                              )
                            ],
                          ),
                          SizedBox(height: 20),
                          signupButton,
                          SizedBox(height: 15),
                        ],
                      ),
                    )))),
      ),
    );
  }

  void signUp(String email, String password) async{
    if(_formkey.currentState!.validate()){
      await _auth.createUserWithEmailAndPassword(email: email,password: password)
          .then((value) => {
        postDetailsToFirestore()
      }).catchError((e){
        Fluttertoast.showToast(msg: e!.message);
      });
    }
  }

  postDetailsToFirestore() async{
    FirebaseFirestore firebaseFirestore=FirebaseFirestore.instance;
    User? user= _auth.currentUser;

    UserModel userModel= UserModel();

    userModel.email = user!.email;
    userModel.uid=user.uid;
    userModel.username=usernameController.text;
    userModel.choice=choice;


    await firebaseFirestore
        .collection("users")
        .doc(user.uid)
        .set(userModel.toMap());

    Fluttertoast.showToast(msg: "Account Created Successfully");

    Navigator.pushAndRemoveUntil((context), MaterialPageRoute(builder: (context)=>IndexPage()),
            (route) => false);
  }
}